#include "seller.h"
#include "product.h"

seller::seller(){
	name = "";
	phone = "";
	address = "";
	email = "";
	date = "";
	account = 0;
}
Product p;
seller::~seller()
{
	 
}
void seller::setName(string n)
{
	name = n;
}
void seller::setPhone(string p)
{
	phone = p;
}
void seller::setAddress(string a)
{
	address = a;
}
void seller::setEmail(string e)
{
	email = e;
}
void seller::setDoB(string DoB)
{
	date = DoB;
}
void seller::setAccount(float Account)
{
	account = Account;
}
string seller::getName()
{
	return name;
}
string seller::getPhone()
{
	return phone;
}
string seller::getAddress()
{
	return address;
}
string seller::getEmail()
{
	return email;
}
string seller::getDate()
{
	return date;
}
float seller::getAccount()
{
	return account;
}
void seller::printInfo()
{
	cout<<"Name: "<<name<<endl;
	cout<<"PhoneNumber: "<<phone<<endl;
	cout<<"Address: "<<address<<endl;
	cout<<"Date of birthday: "<<date<<endl;
	cout<<"Your account: "<<account<<endl;
}
void seller::printBill(float bill)
{
	cout<<"Product: "<<p.getName()<<endl;
	cout<<"Amount: "<<p.getAmount()<<endl;
	cout<<"Total price: "<<p.getTotalPrice()<<endl;
}