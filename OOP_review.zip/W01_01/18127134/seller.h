#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class seller {
private:
	string name;
	string phone;
	string address;
	string email;
	string date;
	float account;
public:
	seller();
	seller(string n, string p, string a, string e, string DoB, float m);
	void setName(string n);
	void setPhone(string p);
	void setAddress(string a);
	void setEmail(string e);
	void setDoB(string DoB);
	void setAccount(float Account);
	string getName();
	string getPhone();
	string getAddress();
	string getEmail();
	string getDate();
	float getAccount();
	void printBill(float bill);
	void printInfo();
	~seller();
};