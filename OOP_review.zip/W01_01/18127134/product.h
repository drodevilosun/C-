#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class Product {
private:
	string name;
	string description;
	float weight;
	float price;
	float amount;
public:
	Product();
	Product(string n, float p);
	float getPrice();
	float getAmount();
	void setPrice(float p);
	string getName();
	string getDescription();
	float getWeight();
	float TotalPrice();
	void printProduct();
	void deleteProduct();
	~Product();
};


