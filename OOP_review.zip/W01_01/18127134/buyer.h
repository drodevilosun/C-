#include <iostream>
#include <string>
#include <string.h>

using namespace std;

class buyer {
private:
	string name;
	string phone;
	string address;
	string email;
	string date;
	float account;
public:
	buyer();
	buyer(string n, string p, string a, string e, string DoB, float m);
	void setName(string n);
	void setPhone(string p);
	void setAddress(string a);
	void setEmail(string e);
	void setDoB(string DoB);
	void setAccount(float Account);
	string getName();
	string getPhone();
	string getAddress();
	string getEmail();
	string getDate();
	float getAccount();
	
	~buyer();
};