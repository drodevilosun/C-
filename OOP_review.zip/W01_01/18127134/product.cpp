#include "product.h"

Product::Product(){
	name = "";
	description = "";
	weight = 0;
	price = 0;
	amount = 0;
}
Product::Product(string Name, float Price){
	name = Name;
	price = Price;
}
float Product::getAmount()
{
	return amount;
}
float Product::getPrice()
{
	return price;
}
float Product::getWeight()
{
	return weight;
}
string Product::getDescription()
{
	return description;
}
string Product::getName()
{
	return name;
}
float Product::TotalPrice()
{
	return amount*price;
}
void Product::printProduct()
{
	cout<<"Name: "<<name<<endl;
	cout<<"Description: "<<description<<endl;
	cout<<"Weight: "<<weight<<endl;
	cout<<"Price: "<<price<<endl;
	cout<<"Amount: "<<amount<<endl;
}
void Product::deleteProduct()
{
	name = "";
	description = "";
	weight = 0;
	price = 0;
	amount = 0;
}
Product::~Product()
{

}