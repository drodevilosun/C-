#include "buyer.h"
#include "product.h"

buyer::buyer(){
	name = "";
	phone = "";
	address = "";
	email = "";
	date = "";
	account = 0;
}
Product p;
buyer::~buyer()
{
	 
}
void buyer::setName(string n)
{
	name = n;
}
void buyer::setPhone(string p)
{
	phone = p;
}
void buyer::setAddress(string a)
{
	address = a;
}
void buyer::setEmail(string e)
{
	email = e;
}
void buyer::setDoB(string DoB)
{
	date = DoB;
}
void buyer::setAccount(float Account)
{
	account = Account;
}
string buyer::getName()
{
	return name;
}
string buyer::getPhone()
{
	return phone;
}
string buyer::getAddress()
{
	return address;
}
string buyer::getEmail()
{
	return email;
}
string buyer::getDate()
{
	return date;
}
float buyer::getAccount()
{
	return account;
}