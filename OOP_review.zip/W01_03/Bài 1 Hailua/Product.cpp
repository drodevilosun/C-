#include "Product.h"

Product::Product()
{
	name = "";
	price = 0;
	describe = "";
	weight = 0;
}
Product::Product(string n)
{
	name = n;
}
Product::Product(string n, float p)
{
	name = n;
	price = p;
}
Product::Product(string n, float p, string d)
{
	name = n;
	price = p;
	describe = d;
}
Product::Product(string n, float p, string d, float w)
{
	name = n;
	price = p;
	describe = d;
	weight = w;
}
void Product::print()
{
	cout << "Product: " << name << endl;
	cout << "Describe: " << describe << endl;
	cout << "Price: " << price << "$" << endl;
	cout << "Weight: " << weight << "gram" << endl;
}
void Product::status(string s)
{
	cout << "Product Status: " << s << endl;
}
void Product::amount(int am)
{
	cout << "Amount:" << am << endl;
}
void Product::fixPrice(float f)
{
	price = f;
	cout << "Price is fixed to: " << price << "$" << endl;
}
void Product::expired(string ex)
{
	cout << "Expired " << ex << endl;
}
float Product::getPrice()
{
	return price;
}
string Product::getName()
{
	return name;
}
Product::~Product() {
}