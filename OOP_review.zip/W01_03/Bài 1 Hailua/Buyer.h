#include "Product.h"


class Buyer {
private:
	string name;
	string address;
	string phone;
	string email;
	string DoB;
public:
	Buyer();
	Buyer(string n);
	Buyer(string n, string a);
	Buyer(string n, string a, string p);
	Buyer(string n, string a, string p, string m);
	Buyer(string n, string a, string p, string m, string d);
	void printinfo();
	void buyProduct(Product p);
	void bill(Product p);
};
