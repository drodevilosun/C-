#include "Product.h"

class Seller {
private:
	string name;
	string address;
	string DoB;
	string phone;
	string email;
public:
	Seller();
	Seller(string n);
	Seller(string n, string a);
	Seller(string n, string a, string p);
	Seller(string n, string a, string p, string e);
	Seller(string n, string a, string p, string e, string d);
	void printinfo();
	string getName();
	void sell(Product p);
	void intro(Product p);
	void ship(Product p);
};
