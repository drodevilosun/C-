#include <iostream>
#include <string>
#include <conio.h>
#ifndef PRODUCT_H
#define PRODUCT_H
using namespace std;

class Product{
private:
	string name;
	float price;
	string describe;
	float weight;
public:
	Product();
	Product(string n);
	Product(string n, float p);
	Product(string n, float p, string d);
	Product(string n, float p, string d, float w);
	~Product();
	void print();
	void status(string s);
	void amount(int am);
	void fixPrice(float f);
	void expired(string ex);
	float getPrice();
	string getName();
};
#endif