#include "Buyer.h"

Buyer::Buyer()
{
	name = "";
	address = "";
	phone = "";
	email = "";
	DoB = "";
}
Buyer::Buyer(string n)
{
	name = n;
}
Buyer::Buyer(string n, string a)
{
	name = n;
	address = a;
}
Buyer::Buyer(string n, string a, string p)
{
	name = n;
	address = a;
	phone = p;
}
Buyer::Buyer(string n, string a, string p, string e)
{
	name = n;
	address = a;
	phone = p;
	email = e;
}
Buyer::Buyer(string n, string a, string p, string e, string d)
{
	name = n;
	address = a;
	phone = p;
	email = e;
	DoB = d;
}
void Buyer::printinfo()
{
	cout << "Information:" << endl;
	cout << "Name: " << name << endl;
	cout << "Address: " << address << endl;
	cout << "Phone number: " << phone << endl;
	cout << "Email: " << email << endl;
	cout << "Day of birth: " << DoB << endl;
}
void Buyer::buyProduct(Product p)
{
	cout << "Trading information:" << endl;
	cout << "Customer: " << name << endl;
	cout << p.getName() << " was bought" << endl<<endl;
}
void Buyer::bill(Product p)
{
	int quantily = 0;
	cout << "Quantily of " << p.getName() << " : "; cin >> quantily;
	cout << "Bill:" << endl;
	cout << "Product: " << p.getName() << endl;
	cout << "Price: " << p.getPrice() << "$" << endl;
	cout << "Total:" << quantily * p.getPrice() << "$" << endl;
}