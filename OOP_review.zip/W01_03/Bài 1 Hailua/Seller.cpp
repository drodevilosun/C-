#include "Seller.h"

Seller::Seller()
{
	name = "";
	address = "";
	phone = "";
	email = "";
	DoB = "";
}
Seller::Seller(string n)
{
	name = n;
}
Seller::Seller(string n, string a)
{
	name = n;
	address = a;
}
Seller::Seller(string n, string a, string p)
{
	name = n;
	address = a;
	phone = p;
}
Seller::Seller(string n, string a, string p, string e)
{
	name = n;
	address = a;
	phone = p;
	email = e;
}
Seller::Seller(string n, string a, string p, string e, string d)
{
	name = n;
	address = a;
	phone = p;
	email = e;
	DoB = d;
}
void Seller::printinfo()
{
	cout << "Information: " << endl;
	cout << "Name: " << name << endl;
	cout << "Address: " << address << endl;
	cout << "Date of birth: " << DoB << endl;
	cout << "Phone number: " << phone << endl;
	cout << "Email: " << email << endl;
}
void Seller::sell(Product p)
{
	cout << "Product sell:" << endl;
	p.print();
}
void Seller::intro(Product p)
{
	cout << "My product was on website hailua.com.vn" << endl;
	cout << "You can buy it on website or contact with me for more information" << endl;
}
void Seller::ship(Product p)
{
	cout << "Your product you bought was shipping to your address" << endl;
}
string Seller::getName()
{
	return name;
}