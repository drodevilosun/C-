#include "Product.h"
#include "Seller.h"
#include "Buyer.h"

int main()
{
	char c;
	float price = 0;
	Product p("Bananas", 2, "Banana is good fruit for your health", 50);
	p.print();
	p.status("In stock");
	p.amount(8000);
	p.expired("1 week from the date you receive the product");
	cout << "Do you want to fix the price? (y/n):";
	cin >> c;
	if (c == 'y')
	{
		cout << "The price you want to fix: "; 
		cin >> price;
		p.fixPrice(price);
	}
	cout << endl << endl;
	Seller s("Long Lucy", "1041/35 Tran Xuan Soan Street", "09899999", "longlucy@gmail.com", "11/1/2000");
	s.printinfo();
	s.sell(p);
	s.intro(p);
	s.ship(p);
	cout << endl << endl;
	Buyer b("Fairy Nguyen", "391 Nguyen Van Bao Street", "038333333", "fairynguyen@gmail.com.", "20/09/2000");
	b.printinfo();
	b.buyProduct(p);
	b.bill(p);
	_getch();
	return 0;
}