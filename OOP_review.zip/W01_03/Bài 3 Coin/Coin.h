#include <iostream>
#include <string>
#include <ctime>
#include <conio.h>
using namespace std;

class Coin
{
private:
	string sideUp;
public:
	Coin();
	void toss();
	string getsideUp();
	~Coin();
};