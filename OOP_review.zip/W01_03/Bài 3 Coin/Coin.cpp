#include "Coin.h"

Coin::Coin() {
	srand(time(0));
	string a[2] = { "heads", "tails" };
	sideUp = a[rand() % 2];
}
void Coin::toss() {
	string a[2] = { "heads", "tails" };
	sideUp = a[rand() % 2];
}
string Coin::getsideUp() {
	return sideUp;
}
Coin::~Coin() {

}