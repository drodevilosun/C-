#include "Coin.h"

void main() {
	Coin a;
	int count1 = 0, count2 = 0;
	string s;
	for (int i = 0; i < 20; i++)
	{
		cout << i + 1 <<": ";
		a.toss();
		cout << a.getsideUp() << endl;
		if (a.getsideUp() == "heads")
			count1++;
		else
			count2++;
	}
	cout << "Head: " << count1 << endl << "Tail: " << count2;
	_getch();
}