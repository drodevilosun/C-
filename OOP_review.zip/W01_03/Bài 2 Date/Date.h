#include <iostream>
#include <string>
#include <conio.h>
#include <algorithm>

using namespace std; 

class Date {
private:
	int day, month, year;
public:
	bool check();
	void input();
	void output();
	void increase1day();
	void increaseNday(int n);
	void decrease1day();
	void decreaseNday(int n);
	void fix(Date &d);
	int compare(Date d);
	int distance();//distance to given date to 1/1/1
	int distance2();//distance from given date to first day of given year
};
