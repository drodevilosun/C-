#include "Date.h"

int main() {
	Date d, d1;
	d.input();
	d.output();
	int x, n;
	cout << endl<< "1: Increase 1 day" << endl << "2: Increase n day" << endl << "3: Decrease 1 day" << endl << "4: Increase n day" << endl<<"5: Compare"<<endl;
	cout << "6: Distance to input date to 1/1/1" << endl << "7: Distance from input date to first day of input year" << endl;
	cin >> x;
	switch (x)
	{
	case 1:
		d.increase1day();
		d.fix(d);
		d.output();
		break; 
	case 2:
		cout << "N: ";
		cin >> n;
		d.increaseNday(n);
		d.fix(d);
		d.output();
		break;
	case 3:
		d.decrease1day();
		d.fix(d);
		d.output();
		break;
	case 4:
		cout << "N: ";
		cin >> n;
		d.decreaseNday(n);
		d.fix(d);
		d.output();
		break;
	case 5:
		cout << "Input to compare:" << endl;
		d1.input();
		if (d.compare(d1) == -1)
			cout << "Date 1 > Date 2";
		else if(d.compare(d1) == 1)
			cout << "Date 1 < Date 2";
		else
			cout << "Date 1 = Date 2";
		break;
	case 6:
		cout << "Input to calculate distance: " << endl;
		d1.input();
		cout << "Distance is: " << d1.distance() << " day";
		break;
	case 7:
		cout << "Input to calculate distance: " << endl;
		d1.input();
		cout << "Distance is: " << d1.distance2() << " day";
		break;
	}
	_getch();
	return 0;
}