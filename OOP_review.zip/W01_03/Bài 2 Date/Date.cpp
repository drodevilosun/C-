#include "Date.h"

bool leapyear(int y) {
	{
		if (y % 100 == 0)
			if (y % 400 == 0)
				return true;
			else
				return false;
		else if (y % 4 == 0) 
			return true;
		else
			return false;
	}
}
bool Date::check() {
	int daymax=0;
	if (year < 0 || month < 0 || month> 12 || day < 0 || day> 31)
		return false;
	else
	{
		switch (month)
		{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			daymax = 31;
			break;
		case 2:
			if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
				daymax = 29;
			else
				daymax = 28;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			daymax = 30;
			break;
		}
		if (day <= daymax)
			return true;
		else
			return false;
	}
}
void Date::input() {
	cout << "Day: ";
	cin >> day;
	cout << "Month: ";
	cin >> month;
	cout << "Year: ";
	cin >> year;
	while (!check()) {
		cout << "Wrong!!" << endl;
		cout << "Day: ";
		cin >> day;
		cout << "Month: ";
		cin >> month;
		cout << "Year: ";
	}
}
void Date::output() {
	cout << day << "/" << month << "/" << year;
}
void Date::increase1day() {
	day += 1;
}
void Date::increaseNday(int n) {
	day += n;
}
void Date::decrease1day() {
	day -= 1;
}
void Date::decreaseNday(int n) {
	day -= n;
}
void Date::fix(Date &d)
{
	int c = 0;
	if (d.day > 0) c = 1;
	else c = 2;
	switch (c)
	{
	case 1:
	{
		if(leapyear(d.year) && d.month==2)
			if (d.day > 29)
			{
				d.day -= 29;
				d.month += 1;
			}
		if (!leapyear(d.year) && d.month == 2)
			if (d.day > 28)
			{
				d.day -= 28;
				d.month += 1;
			}
		if(d.month==1 || d.month == 3 || d.month == 5 || d.month == 7 || d.month == 8 || d.month == 10 || d.month == 12)
			if (d.day > 31) 
			{
				d.day -= 31;
				d.month += 1;
			}
		if (d.month == 4 || d.month == 6 || d.month == 9 || d.month == 11)
			if (d.day > 30)
			{
				d.day -= 30;
				d.month += 1;
			}
		if (d.month > 12)
		{
			d.month -= 12;
			d.year += 1;
		}
	}
	case 2:
	{
		if (leapyear(d.year) && d.month == 3)
			if (d.day <= 0)
			{
				d.day += 29;
				d.month -= 1;
			}
		if (!leapyear(d.year) && d.month == 3)
			if (d.day > 28)
			{
				d.day += 28;
				d.month -= 1;
			}
		if (d.month == 5 || d.month == 7 || d.month == 10 || d.month == 12)
			if (d.day <= 0) {
				d.day = 30 + d.day;
				d.month -= 1;
			}
		if (d.month == 1 || d.month == 2 || d.month == 4 || d.month == 6 || d.month == 8 || d.month == 9 || d.month == 11)
			if (d.day <= 0) {
				d.day = 31 + d.day;
				d.month -= 1;
			}
		if (d.month < 1)
		{
			d.month = 12 + d.month;
			d.year -= 1;
		}
	}
	}
}
int Date::compare(Date d) {
	if (d.year < year)
		return -1;
	else if (d.year > year)
		return 1;
	else
		if (d.month < month)
			return -1;
		else if (d.month > month)
			return 1;
		else 
			if (d.day < day)
				return -1;
			else if (d.day > day)
				return 1;
			else return 0;
}
int CountDay(int d, int m, int y)
{
	int DayofMonth[2][12] = { {31,29,31,30,31,30,31,31,30,31,30,31},{31,28,31,30,31,30,31,31,30,31,30,31} };
	int i=0;
	int f = d;
	if (leapyear(y)) 
		i = 0;
	else 
		i = 1;
	for (int j = 0; j < m - 1; j++)  
		f += DayofMonth[i][j];
	return f;
}
int DayofYear(int y)
{
	if (leapyear(y)) 
		return 366;
	return 365;
}
int Date::distance() {
	Date defaultt;
	defaultt.day = 1;
	defaultt.month = 1;
	defaultt.year = 1;
	int f = 0;
	int flag1 = CountDay(defaultt.day, defaultt.month, defaultt.year);
	int flag2 = CountDay(day, month, year);
	if (defaultt.year == year) 
		return(abs(flag1 - flag2));
	if (defaultt.year < year)
	{
		flag1 = DayofYear(defaultt.year) - flag1;
		for (int i = defaultt.year + 1; i < year; i++)
			f += DayofYear(i);
		return(f + flag1 + flag2);
	}
	else
	{
		flag2 = DayofYear(year) - flag2;
		for (int i = year + 1; i < defaultt.year; i++)
			f += DayofYear(i);
		return(f + flag1 + flag2);
	}
}
int Date::distance2() {
	Date defaultt;
	defaultt.day = 1;
	defaultt.month = 1;
	defaultt.year = year;
	int flag1 = CountDay(defaultt.day, defaultt.month, defaultt.year);
	int flag2 = CountDay(day, month, year);
	return (flag2 - flag1);
}