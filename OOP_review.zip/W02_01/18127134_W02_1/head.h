#include <iostream>
#include <cmath>


using namespace std;

class Fraction{
private:
	int Nu;
	int De;
public:
	Fraction();
	Fraction(int nu, int de);
	Fraction( const Fraction &f);
	int GCD(Fraction &a);
	Fraction Reduce(Fraction &a);
	Fraction operator+(const Fraction &a);
	Fraction operator-(const Fraction &a);
	Fraction operator*(const Fraction &a);
	Fraction operator/(const Fraction &a);
	Fraction operator+(int a);
	Fraction operator-(int a);
	Fraction operator*(int a);
	Fraction operator/(int a);
	Fraction& operator = (const Fraction &a);
	bool operator==(const Fraction &a);
	bool operator!=(const Fraction &a);
	bool operator<(const Fraction &a);
	bool operator>(const Fraction &a);
	bool operator<=(const Fraction &a);
	bool operator>=(const Fraction &a);
	friend ostream& operator<<(ostream &os, Fraction &a);

	int getNu();
	int getDe();
	~Fraction();
};

