#include "head.h"

Fraction::Fraction(){
	Nu=0;
	De=1;
}
Fraction::Fraction(int nu, int de){
	Nu=nu;
	if(de!=0)
		if(de<0)
		{
			De=-de;
			Nu*=-1;	
		}
		else De=de;
}
Fraction::Fraction(const Fraction &f){
	Nu=f.Nu;
	De=f.De;
}
int Fraction::getNu(){
	return Nu;
}
int Fraction::getDe(){
	return De;
}
int Fraction::GCD(Fraction &a)// Tim UCLN
       {            
           a.Nu=abs(a.Nu); 
           a.De=abs(a.De);            
           if (a.Nu==0 ||a.De==0)
               return a.Nu+a.De;
           while (a.Nu !=a.De)
           {
               if(a.Nu>a.De)
                   a.Nu=a.Nu-a.De;
               else
                   a.De=a.De-a.Nu;
           }
           return a.Nu;
       }
Fraction Fraction::Reduce(Fraction &a)
{
	a.Nu=a.Nu/GCD(a);
	a.De=a.De/GCD(a);
	return a;
}
Fraction Fraction::operator+(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.De + De*a.Nu;
	rs.De = De*a.De;
	Reduce(rs);
	return rs;
}
Fraction Fraction::operator-(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.De - De*a.Nu;
	rs.De = De*a.De;
	Reduce(rs);
	return rs;
}
Fraction Fraction::operator*(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.Nu;
	rs.De = De*a.De;
	Reduce(rs);
	return rs;
}
Fraction Fraction::operator/(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.De;
	rs.De = De*a.Nu;
	Reduce(rs);
	return rs;
}
Fraction Fraction::operator+(int a){
	Nu=Nu + a*De;
	return *this;
}
Fraction Fraction::operator-(int a){
	Nu=Nu - a*De;
	return *this;
}
Fraction Fraction::operator*(int a){
	Nu=Nu * a;
	return *this;
}
Fraction Fraction::operator/(int a){
	if(a==0)
	{
		Nu=0;
		De=1;
	}
	else
		De=De * a;
	return *this;
}
Fraction& Fraction::operator=(const Fraction &a){
	if(this==&a)
		return *this;
	this->Nu=a.Nu;
	this->De=a.De;
	return *this;
}
bool Fraction::operator==(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.De - De*a.Nu;
	if(rs.Nu==0)
		return true;
	return false;
}
bool Fraction::operator!=(const Fraction &a){
	Fraction rs;
	rs.Nu = Nu*a.De - De*a.Nu;
	if(rs.Nu==0)
		return false;
	return true;
}
bool Fraction::operator<(const Fraction &a){
	int x = Nu*a.De + a.Nu*De;
	if(x<0)
		return true;
	return false;
}
bool Fraction::operator>(const Fraction &a){
	int x = Nu*a.De + a.Nu*De;
	if(x>0)
		return true;
	return false;
}
bool Fraction::operator<=(const Fraction &a){
	int x = Nu*a.De + a.Nu*De;
	if(x<=0)
		return true;
	return false;
}
bool Fraction::operator>=(const Fraction &a){
	int x = Nu*a.De + a.Nu*De;
	if(x>=0)
		return true;
	return false;
}
ostream& operator<<(ostream &os, Fraction &a){
	os<<a.Nu<<"/"<<a.De;
	return os;
}
Fraction::~Fraction(){
}
