#include "head.h"

int main()
{
	Fraction f1, f2; // 0/1
	Fraction f3(1,-7); // -1/7
	Fraction f4(f3); // Copy constructor
	Fraction f5=f2; // Copy constructor
	Fraction f6, f7, f8; // Default constructor
	f6=f3; // Operator =
	f7=f1+f5;
	f8=f2-f4;
	f3=f1*f7;
	f5=f6/f2;
	if(f2==f3)
		cout<<"f2==f3"<<endl;
	if(f3!=f1)
		cout<<"f3!=f1"<<endl;
	if(f2>=f5)
		cout<<"f2>=f5"<<endl;
	if(f2>f5)
		cout<<"f2>f5"<<endl;
	if(f5<=f3)
		cout<<"f5<=f3"<<endl;
	if(f5<f3)
		cout<<"f5<f3"<<endl;

	system("pause");
	return 0;
}